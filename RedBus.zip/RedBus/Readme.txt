Please download selenium from here:https://mvnrepository.com/artifact/org.seleniumhq.selenium/selenium-java/4.25.0
download driver from here= https://googlechromelabs.github.io/chrome-for-testing/#stable
githubURL=https://github.com/atharavyadav/batch45
testngurl=https://mvnrepository.com/artifact/org.testng/testng/7.10.2
maven dependency for logger core: https://mvnrepository.com/artifact/org.apache.logging.log4j/log4j-core/3.0.0-beta2

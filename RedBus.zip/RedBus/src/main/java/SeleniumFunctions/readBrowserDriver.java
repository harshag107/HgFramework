package SeleniumFunctions;
//Author:neelam
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.chrome.ChromeOptions;

import Configurations.ReusableData;

public class readBrowserDriver {
	 public static  WebDriver driver ;
	public static void readbrowser(String browsertype,String path,String url)
	{
		if(ReusableData.Headless_Execution=="Yes")

		{
           ChromeOptions option = new ChromeOptions();
			option.addArguments("--headless");
			System.setProperty(browsertype, path);

			if(ReusableData.Env=="QA") {

				driver=new ChromeDriver(option);

				driver.get(url);

			}

			else if(ReusableData.Env=="PROD"){

				driver=new ChromeDriver(option);

				driver.get(url);
			}
		}

		else {

			System.setProperty(browsertype, path);

			if(ReusableData.Env=="QA") {

				driver=new ChromeDriver();

				driver.get(url);

			}

		
			else if(ReusableData.Env=="PROD"){

				driver=new ChromeDriver();

				driver.get(url);

			}
		}

		}
	
	public static void maximizeBroser()
	{
		driver.manage().window().maximize();
	}


	
}

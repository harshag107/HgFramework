package Seleniumfunction;

public class firstSelenium {
	
   public void driver() {
	
}
}

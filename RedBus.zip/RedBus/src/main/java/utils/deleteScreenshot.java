package utils;

import java.io.File;
import java.io.IOException;

import org.apache.commons.io.FileUtils;
import org.openqa.selenium.Alert;
import org.openqa.selenium.By;
import org.openqa.selenium.OutputType;
import org.openqa.selenium.TakesScreenshot;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;

import SeleniumFunctions.readBrowserDriver;



public class  deleteScreenshot {
    public static void deletealertscreenshot() throws IOException
    {
    	
    		
    		readBrowserDriver.driver.findElement(By.xpath("//input[@name='submit']")).click();
    		Alert obj = readBrowserDriver.driver.switchTo().alert();
    		String msg1 = obj.getText();
    		System.out.println(msg1);
    		obj.accept();
    		String msg = obj.getText();
    		System.out.println(msg);
    		//obj.dismiss();
    		
    		TakesScreenshot sc = (TakesScreenshot)readBrowserDriver.driver;
    		File file = sc.getScreenshotAs(OutputType.FILE);
    		FileUtils.copyFile(file, new File("C:\\Users\\Dell\\eclipse\\RedBus\\RedBus\\screenShot\\alert_handled_screenshot.png"));
           
    }
}

package SeleniumFunctions;

import java.awt.Desktop.Action;
import java.awt.event.ActionEvent;
import java.io.File;
import java.io.IOException;
import java.time.Duration;
import java.util.NoSuchElementException;
import java.util.concurrent.TimeoutException;
import java.util.logging.FileHandler;

import org.openqa.selenium.Alert;
import org.openqa.selenium.By;
import org.openqa.selenium.By.ByXPath;
import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.OutputType;
import org.openqa.selenium.TakesScreenshot;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.interactions.Actions;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.Select;
import org.openqa.selenium.support.ui.WebDriverWait;

import Configurations.ReusableData;
import excel.readDataFromExcel;

public class seleniumUIActions {
	
	public static void enterVlues() throws IOException
	{
		readBrowserDriver.driver.findElement(By.xpath(readdatafromfile.readdatafromOR("Register.ContactInformation.FirstName.input"))).sendKeys(readDataFromExcel.fetchexcelData(0, 1));
		readBrowserDriver.driver.findElement(By.xpath(readdatafromfile.readdatafromOR("Register.ContactInformation.lastName.input"))).sendKeys(readDataFromExcel.fetchexcelData(0, 2));
	
	}

	public static void clickHomes() throws IOException
	{
		readBrowserDriver.driver.findElement(By.xpath(readdatafromfile.readdatafromOR("Register.HomePage.a"))).click();
		
	
	}
	
	public static void selectdropdown() throws IOException
	{
		
		WebElement ele = readBrowserDriver.driver.findElement(By.xpath(readdatafromfile.readdatafromOR("Register.MailingInfo.Country.select")));
		Select sel = new Select(ele);
		sel.selectByValue("ALGERIA");
		
	
	}
	
	public static void handleAlert() throws IOException
	{
		readBrowserDriver.driver.findElement(By.xpath("//input[@name='submit']")).click();
		Alert obj = readBrowserDriver.driver.switchTo().alert();
		String msg1 = obj.getText();
		System.out.println(msg1);
		obj.accept();
		String msg = obj.getText();
		System.out.println(msg);
		//obj.dismiss();
		
	
	}
	public static void handlewait() throws TimeoutException
	{
		//hard code wait or implicit wait

				//explicit wait

				//fluent wait

		/*		readBrowserDriver.driver.findElement(By.xpath("//button[@id='btn1']")).click();
                  try {
					readBrowserDriver.driver.manage().timeouts().implicitlyWait(Duration.ofSeconds(1));
				} catch (NoSuchElementException e) {
					readBrowserDriver.driver.manage().timeouts().implicitlyWait(Duration.ofSeconds(8));
					readBrowserDriver.driver.findElement(By.xpath("(//input[@id='txt1'])[1]")).click();

				}  */
 

		//1 st button
	     	readBrowserDriver.driver.findElement(By.xpath("//button[@id='btn1']")).click();
            WebDriverWait wait = new WebDriverWait(readBrowserDriver.driver, Duration.ofSeconds(20));
	        wait.until(ExpectedConditions.visibilityOfElementLocated(By.xpath("(//input[@id='txt1'])[1]"))).sendKeys("Harsha");  

	        // 2nd button
	        readBrowserDriver.driver.findElement(By.xpath("//button[@id='btn2']")).click();
	        WebDriverWait waits = new WebDriverWait(readBrowserDriver.driver, Duration.ofSeconds(20));
	        waits.until(ExpectedConditions.visibilityOfElementLocated(By.xpath("(//input[@id='txt12'])[1]"))).sendKeys("Gurav"); 
	         
	    }
	
	public static void switchwindow() throws Exception
	{
		Thread.sleep(1000);
		readBrowserDriver.driver.findElement(By.xpath("//button[@id=\"windowButton\"]")).click();
	   String mycurrentwindow = readBrowserDriver.driver.getWindowHandle();
	   System.out.println(mycurrentwindow);
	}
	public static void switchwindowX() throws Exception
	{
		Thread.sleep(1000);
	/*	readBrowserDriver.driver.findElement(By.xpath("//button[@id=\"messageWindowButton\"]")).click();
	  // String mycurrentwindow = readBrowserDriver.driver.getWindowHandle();
	  // System.out.println(mycurrentwindow);
	   Alert obj = readBrowserDriver.driver.switchTo().alert();
		String msg1 = obj.getText();
		System.out.println(msg1);
		obj.accept();
		String msg = obj.getText();
		System.out.println(msg);  */
		
		
	//	WebDriverWait wait = new WebDriverWait(readBrowserDriver.driver, Duration.ofSeconds(20));
		readBrowserDriver.driver.findElement(By.xpath("//button[@id=\"messageWindowButton\"]")).click();

		  WebDriverWait wait = new WebDriverWait(readBrowserDriver.driver, Duration.ofSeconds(10));
	        Alert popup = wait.until(ExpectedConditions.alertIsPresent());

	        // Get the message from the popup
	        String message = popup.getText();
	        System.out.println("Popup message: " + message);

	        // Close the popup
	        popup.accept();
	}
	
	public static void clickButton_alert1() throws IOException
	{
		readBrowserDriver.driver.findElement(By.xpath("//button[@id='alertButton']")).click();
		readBrowserDriver.driver.manage().timeouts().implicitlyWait(Duration.ofSeconds(5));
		Alert obj1 = readBrowserDriver.driver.switchTo().alert();
		String msg2 = obj1.getText();
		System.out.println(msg2);
		obj1.accept();
		
	}
	public static void clickButton_alert2() throws IOException
	{
		readBrowserDriver.driver.findElement(By.xpath("//button[@id='timerAlertButton']")).click();
		WebDriverWait wait = new WebDriverWait(readBrowserDriver.driver, Duration.ofSeconds(5));
		   Alert alert = wait.until(ExpectedConditions.alertIsPresent());
		    String alertText = alert.getText();
		    System.out.println("Simple Alert Text: " + alertText);
		    alert.accept();
		}
	public static void confirmBox() throws IOException, Exception
	{
		//readBrowserDriver.driver.findElement(By.xpath("//button[@id='confirmButton']")).click();
		
	 WebElement confirmButton = readBrowserDriver.driver.findElement(By.xpath("//button[@id='confirmButton']"));

	        WebDriverWait wait = new WebDriverWait(readBrowserDriver.driver, Duration.ofSeconds(20));
	        wait.until(ExpectedConditions.elementToBeClickable(confirmButton));
	        confirmButton.click();

	        wait.until(ExpectedConditions.alertIsPresent());
	        Alert confirm = readBrowserDriver.driver.switchTo().alert();
	        String message = confirm.getText();
	        System.out.println("Alert message: " + message);
	        confirm.accept();
	        WebElement result = readBrowserDriver.driver.findElement(By.xpath("//span[@id='confirmResult']"));
	        System.out.println("Result after accepting alert: " + result.getText());   
		

	}
	
	public static void promptBox() throws IOException, Exception
	{ 
	
	             WebElement promptButton = readBrowserDriver.driver.findElement(By.xpath("//button[@id='promtButton']"));		
                 WebDriverWait wait = new WebDriverWait(readBrowserDriver.driver, Duration.ofSeconds(20));
                 wait.until(ExpectedConditions.elementToBeClickable(promptButton));
                 promptButton.click();

                 wait.until(ExpectedConditions.alertIsPresent());

                 Alert promptAlert = readBrowserDriver.driver.switchTo().alert();
                 System.out.println("Prompt Alert Text: " + promptAlert.getText());
                 promptAlert.sendKeys("Harsha Gurav");
                 promptAlert.accept();
                 Thread.sleep(2000);

                WebElement result = readBrowserDriver.driver.findElement(By.xpath("//span[@id='promptResult']"));
                 System.out.println("Result after accepting prompt: " + result.getText());  
		

		}

	public static void switch_frame()
	{
		readBrowserDriver.driver.switchTo().frame("a077aa5e");
		WebElement ele = readBrowserDriver.driver.findElement(By.xpath("//a[@href=\"http://www.guru99.com/live-selenium-project.html\"]"));
		JavascriptExecutor js = (JavascriptExecutor)readBrowserDriver.driver;

		js.executeScript("arguments[0].click", ele);
		
	}

	private static void print(String string) {
		// TODO Auto-generated method stub
		
	}
}






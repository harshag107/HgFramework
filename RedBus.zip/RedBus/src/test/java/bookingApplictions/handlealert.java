package bookingApplictions;

import java.io.IOException;

import org.testng.annotations.AfterMethod;
import org.testng.annotations.BeforeMethod;
import org.testng.annotations.Test;

import Configurations.ReusableData;
import SeleniumFunctions.readBrowserDriver;
import SeleniumFunctions.seleniumUIActions;
import utils.takeScreenshot;

public class handlealert {
	@BeforeMethod
	public void precodition() throws IOException
	{
		readBrowserDriver.readbrowser(ReusableData.chromedriverpath,ReusableData.browsertype,ReusableData.alerturl);
	 //  readBrowserDriver.readbrowser(ReusableData.chromedriverpath,ReusableData.browsertype,ReusableData.demo_alert_url);
		//readBrowserDriver.readbrowser(ReusableData.chromedriverpath,ReusableData.browsertype,ReusableData.frame_alert_url);	
		readBrowserDriver.maximizeBroser();
	}
	@Test(priority = 1)
	public void handleAlert() throws Exception
	{
		//seleniumUIActions.clickButton_alert1();
		//seleniumUIActions.clickButton_alert2();
		//seleniumUIActions.confirmBox();
		//seleniumUIActions.promptBox();
	    //takeScreenshot.takescreenshot();
	//	takeScreenshot.deletecreenshot();
	//	seleniumUIActions.handleAlert();
		
	     
	}
	
	@AfterMethod
	public void closebrowser() throws IOException, Exception
	{
		Thread.sleep(3000);
	    //readBrowserDriver.driver.close();
	}
}

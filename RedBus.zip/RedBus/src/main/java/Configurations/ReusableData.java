package Configurations;
//Author:neelam
public interface ReusableData {
	
	public static String browsertype="webdriver.chrome.driver";
	public static String browsertype_edge="webdriver.chrome.driver";
	public static String chromedriverpath="C:\\Users\\Dell\\eclipse\\RedBus\\RedBus\\Browser\\chromedriver.exe";
	public static String edgedriverpath="C:\\Users\\Dell\\eclipse\\RedBus\\RedBus\\Browser\\chromedriver.exe";
	public static String url="https://demo.guru99.com/test/newtours/register.php";
	public static String alerturl="https://demo.guru99.com/test/delete_customer.php";
	public static String Env="QA";
	public static String Headless_Execution="Yes";
	public static String PROD_url="https://www.redbus.com/";
	public static String OR_File_Location="C:\\Users\\Dell\\eclipse\\RedBus\\RedBus\\ObjectProperties\\OR.properties";
	public static String Excel_File_Location="C:\\Users\\Dell\\eclipse\\RedBus\\RedBus\\src\\test\\resources\\testData\\testData.xlsx";
	public static String waits_url="https://www.hyrtutorials.com/p/waits-demo.html";
	public static String window_url="https://demoqa.com/browser-windows";
	public static String demo_alert_url="https://demoqa.com/alerts";
	public static String frame_alert_url="https://demo.guru99.com/test/guru99home/";
}

package bookingApplictions;
import java.io.IOException;

import org.testng.annotations.AfterMethod;
import org.testng.annotations.BeforeMethod;
//Author:neelam
import org.testng.annotations.Test;

import Configurations.ReusableData;
import SeleniumFunctions.readBrowserDriver;

public class registerbooking {
	@BeforeMethod
	public void precodition() throws IOException
	{
		readBrowserDriver.readbrowser(ReusableData.chromedriverpath,ReusableData.browsertype,ReusableData.url);
		readBrowserDriver.maximizeBroser();
	}
	@Test
	public void launchBrowser()
	{
		readBrowserDriver.readbrowser(ReusableData.chromedriverpath,ReusableData.browsertype,ReusableData.url);
	    readBrowserDriver.maximizeBroser();
	}
	
	@AfterMethod
	public void closebrowser() throws IOException
	{
		
	    readBrowserDriver.driver.close();
	}
}

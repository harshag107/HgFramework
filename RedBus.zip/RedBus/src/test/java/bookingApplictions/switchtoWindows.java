package bookingApplictions;

import java.io.IOException;

import org.testng.annotations.AfterMethod;
import org.testng.annotations.BeforeMethod;
import org.testng.annotations.Test;

import Configurations.ReusableData;
import SeleniumFunctions.readBrowserDriver;
import SeleniumFunctions.seleniumUIActions;
import utils.takeScreenshot;

public class switchtoWindows {

	@BeforeMethod
	public void precodition() throws IOException
	{
		readBrowserDriver.readbrowser(ReusableData.chromedriverpath,ReusableData.browsertype,ReusableData.window_url);
		readBrowserDriver.maximizeBroser();
	}
	@Test(priority = 1)
	public void switchtowindows() throws Exception
	{
		
		//readBrowserDriver.readbrowser(ReusableData.chromedriverpath,ReusableData.browsertype,ReusableData.alerturl);
	  //  readBrowserDriver.maximizeBroser();
	    
		//takeScreenshot.takescreenshot();
		//seleniumUIActions.switchwindow();
		seleniumUIActions.switchwindowX();
	       
	}

	//id="frame1"
	@AfterMethod
	public void closebrowser() throws IOException, Exception
	{
		Thread.sleep(3000);
	   // readBrowserDriver.driver.close();
	}
}

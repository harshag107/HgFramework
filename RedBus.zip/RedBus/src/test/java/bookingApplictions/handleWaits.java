package bookingApplictions;

import java.io.IOException;
import java.util.concurrent.TimeoutException;

import org.testng.annotations.AfterMethod;
import org.testng.annotations.BeforeMethod;
import org.testng.annotations.Test;

import Configurations.ReusableData;
import SeleniumFunctions.readBrowserDriver;
import SeleniumFunctions.seleniumUIActions;

public class handleWaits {
@BeforeMethod
	public void precodition() throws IOException
	{
		System.out.println("Before driver...");
		
		
		readBrowserDriver.readbrowser(ReusableData.browsertype,ReusableData.chromedriverpath,ReusableData.waits_url);
		readBrowserDriver.maximizeBroser();
		System.out.println("After driver...");
	}
	@Test(priority = 1)
	public void handlewaitsmethod() throws IOException, TimeoutException
	{
		
		
	  //  seleniumUIActions.handlewait();
	    
	}
	
	@AfterMethod
	public void closebrowser() throws IOException
	{
		
	  readBrowserDriver.driver.close();
	}
}



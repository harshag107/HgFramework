package bookingApplictions;
import java.io.IOException;

import org.testng.annotations.AfterMethod;
import org.testng.annotations.BeforeMethod;
//Author:neelam
import org.testng.annotations.Test;

import Configurations.ReusableData;
import SeleniumFunctions.readBrowserDriver;
import SeleniumFunctions.seleniumUIActions;

public class bookTickets {
	
	@BeforeMethod
	public void precodition() throws IOException
	{
		readBrowserDriver.readbrowser(ReusableData.chromedriverpath,ReusableData.browsertype,ReusableData.url);
		readBrowserDriver.maximizeBroser();
	}
	
	@Test(priority = 1)
	public void launchBrowser() throws IOException
	{
	    seleniumUIActions.enterVlues();
	    seleniumUIActions.selectdropdown();
	}
	
	@Test(priority = 2)
	public void clickonHome() throws IOException
	{
		
	    seleniumUIActions.clickHomes();
	}
	
	@AfterMethod
	public void closebrowser() throws IOException
	{
		
	    readBrowserDriver.driver.close();
	}
}
package utils;

import java.io.File;
import java.io.IOException;
import java.util.logging.FileHandler;

import org.apache.commons.io.FileUtils;
import org.openqa.selenium.Alert;
import org.openqa.selenium.By;
import org.openqa.selenium.OutputType;
import org.openqa.selenium.TakesScreenshot;
import org.openqa.selenium.WebElement;

import SeleniumFunctions.readBrowserDriver;

public class takeScreenshot {

	
	
	public static void takescreenshot() throws IOException 
	{
		TakesScreenshot sc = (TakesScreenshot)readBrowserDriver.driver;
		File file = sc.getScreenshotAs(OutputType.FILE);
		FileUtils.copyFile(file, new File("C:\\Users\\Dell\\eclipse\\RedBus\\RedBus\\screenShot\\alert.png"));
	}
	
}
